from django.urls import path
from . import views
urlpatterns=[
 path('',views.inicio,name='inicio'), path('registro/',views.registro,name='registro'),
 path('perfil/',views.perfil,name='perfil'), path('perfil/editar/',views.editar_perfil,name='editar_perfil'),
 path('inmuebles/nuevo/',views.inmueble_crear,name='inmueble_crear'),
 path('inmuebles/mios/',views.mis_inmuebles,name='mis_inmuebles'),
 path('inmuebles/<int:pk>/editar/',views.inmueble_editar,name='inmueble_editar'),
 path('inmuebles/<int:pk>/eliminar/',views.inmueble_eliminar,name='inmueble_eliminar'),
]
