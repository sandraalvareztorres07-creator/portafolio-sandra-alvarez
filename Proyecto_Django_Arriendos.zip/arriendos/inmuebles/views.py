from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404
from .forms import RegistroUsuarioForm, PerfilForm, InmuebleForm
from .models import Inmueble, PerfilUsuario, Region, Comuna


def inicio(request):
    inmuebles=Inmueble.objects.filter(disponible=True).select_related('comuna__region','tipo_inmueble','arrendador')
    comuna=request.GET.get('comuna'); region=request.GET.get('region')
    if comuna: inmuebles=inmuebles.filter(comuna_id=comuna)
    if region: inmuebles=inmuebles.filter(comuna__region_id=region)
    return render(request,'inmuebles/inicio.html',{'inmuebles':inmuebles,'comunas':Comuna.objects.select_related('region'),'regiones':Region.objects.all(),'comuna_sel':comuna or '','region_sel':region or ''})

def registro(request):
    if request.user.is_authenticated: return redirect('perfil')
    form=RegistroUsuarioForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        u=form.save(); login(request,u); messages.success(request,'Usuario registrado correctamente.'); return redirect('perfil')
    return render(request,'registration/registro.html',{'form':form})

@login_required
def perfil(request):
    perfil,_=PerfilUsuario.objects.get_or_create(usuario=request.user)
    propios=Inmueble.objects.filter(arrendador=request.user) if perfil.tipo_usuario==PerfilUsuario.ARRENDADOR else Inmueble.objects.none()
    return render(request,'inmuebles/perfil.html',{'perfil':perfil,'propios':propios})

@login_required
def editar_perfil(request):
    perfil,_=PerfilUsuario.objects.get_or_create(usuario=request.user)
    form=PerfilForm(request.POST or None,instance=perfil)
    if request.method=='POST' and form.is_valid(): form.save(); messages.success(request,'Datos personales actualizados.'); return redirect('perfil')
    return render(request,'inmuebles/editar_perfil.html',{'form':form})

def _exigir_arrendador(user):
    perfil,_=PerfilUsuario.objects.get_or_create(usuario=user)
    if perfil.tipo_usuario != PerfilUsuario.ARRENDADOR: raise PermissionDenied('Solo los arrendadores pueden administrar inmuebles.')
    return perfil

@login_required
def inmueble_crear(request):
    _exigir_arrendador(request.user)
    form=InmuebleForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        obj=form.save(commit=False); obj.arrendador=request.user; obj.save(); messages.success(request,'Inmueble creado correctamente.'); return redirect('mis_inmuebles')
    return render(request,'inmuebles/inmueble_form.html',{'form':form,'titulo':'Agregar inmueble'})

@login_required
def mis_inmuebles(request):
    _exigir_arrendador(request.user)
    return render(request,'inmuebles/mis_inmuebles.html',{'inmuebles':Inmueble.objects.filter(arrendador=request.user).select_related('comuna')})

@login_required
def inmueble_editar(request,pk):
    _exigir_arrendador(request.user); obj=get_object_or_404(Inmueble,pk=pk,arrendador=request.user)
    form=InmuebleForm(request.POST or None,instance=obj)
    if request.method=='POST' and form.is_valid(): form.save(); messages.success(request,'Inmueble actualizado.'); return redirect('mis_inmuebles')
    return render(request,'inmuebles/inmueble_form.html',{'form':form,'titulo':'Actualizar inmueble'})

@login_required
def inmueble_eliminar(request,pk):
    _exigir_arrendador(request.user); obj=get_object_or_404(Inmueble,pk=pk,arrendador=request.user)
    if request.method=='POST': obj.delete(); messages.success(request,'Inmueble eliminado.'); return redirect('mis_inmuebles')
    return render(request,'inmuebles/inmueble_confirm_delete.html',{'inmueble':obj})
