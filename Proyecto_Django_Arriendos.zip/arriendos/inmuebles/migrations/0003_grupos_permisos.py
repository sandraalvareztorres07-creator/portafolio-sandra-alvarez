from django.db import migrations


def configurar_grupos(apps, schema_editor):
    Group = apps.get_model('auth', 'Group')
    Permission = apps.get_model('auth', 'Permission')
    ContentType = apps.get_model('contenttypes', 'ContentType')

    content_type, _ = ContentType.objects.get_or_create(app_label='inmuebles', model='inmueble')
    nombres = {
        'view_inmueble': 'Can view inmueble',
        'add_inmueble': 'Can add inmueble',
        'change_inmueble': 'Can change inmueble',
        'delete_inmueble': 'Can delete inmueble',
    }
    permisos = {}
    for codename, nombre in nombres.items():
        permisos[codename], _ = Permission.objects.get_or_create(
            codename=codename,
            content_type=content_type,
            defaults={'name': nombre},
        )

    arrendatarios, _ = Group.objects.get_or_create(name='Arrendatarios')
    arrendadores, _ = Group.objects.get_or_create(name='Arrendadores')
    arrendatarios.permissions.set([permisos['view_inmueble']])
    arrendadores.permissions.set(list(permisos.values()))


def revertir(apps, schema_editor):
    Group = apps.get_model('auth', 'Group')
    Group.objects.filter(name__in=['Arrendatarios', 'Arrendadores']).delete()


class Migration(migrations.Migration):
    dependencies = [
        ('inmuebles', '0002_crear_superusuario_demo'),
    ]
    operations = [migrations.RunPython(configurar_grupos, revertir)]
