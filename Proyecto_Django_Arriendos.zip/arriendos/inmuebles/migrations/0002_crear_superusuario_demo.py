from django.conf import settings
from django.db import migrations


def crear_superusuario(apps, schema_editor):
    User = apps.get_model(*settings.AUTH_USER_MODEL.split('.'))
    username = 'admin_inmuebles'
    if not User.objects.filter(username=username).exists():
        usuario = User(
            username=username,
            email='admin@inmuebles.cl',
            is_staff=True,
            is_superuser=True,
            is_active=True,
        )
        usuario.set_password('AdminInmuebles#2026')
        usuario.save()


def eliminar_superusuario(apps, schema_editor):
    User = apps.get_model(*settings.AUTH_USER_MODEL.split('.'))
    User.objects.filter(username='admin_inmuebles').delete()


class Migration(migrations.Migration):
    dependencies = [
        ('inmuebles', '0001_initial'),
    ]
    operations = [
        migrations.RunPython(crear_superusuario, eliminar_superusuario),
    ]
