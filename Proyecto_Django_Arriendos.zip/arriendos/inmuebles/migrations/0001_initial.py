from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(
            name='Region',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=100, unique=True)),
            ],
            options={'ordering': ['nombre']},
        ),
        migrations.CreateModel(
            name='TipoInmueble',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=100, unique=True)),
            ],
        ),
        migrations.CreateModel(
            name='PerfilUsuario',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('rut', models.CharField(blank=True, max_length=12)),
                ('direccion', models.CharField(blank=True, max_length=200)),
                ('telefono', models.CharField(blank=True, max_length=20)),
                ('tipo_usuario', models.CharField(choices=[('arrendatario', 'Arrendatario'), ('arrendador', 'Arrendador')], default='arrendatario', max_length=20)),
                ('usuario', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='perfil', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Comuna',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=100)),
                ('region', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='comunas', to='inmuebles.region')),
            ],
            options={'ordering': ['nombre']},
        ),
        migrations.AddConstraint(
            model_name='comuna',
            constraint=models.UniqueConstraint(fields=('nombre', 'region'), name='comuna_region_unica'),
        ),
        migrations.CreateModel(
            name='Inmueble',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=200)),
                ('descripcion', models.TextField()),
                ('m2_construidos', models.PositiveIntegerField(default=0)),
                ('m2_totales', models.PositiveIntegerField(default=0)),
                ('cantidad_estacionamientos', models.PositiveIntegerField(default=0)),
                ('cantidad_habitaciones', models.PositiveIntegerField(default=0)),
                ('cantidad_banos', models.PositiveIntegerField(default=0)),
                ('direccion', models.CharField(max_length=200)),
                ('precio_mensual', models.DecimalField(decimal_places=2, max_digits=12)),
                ('disponible', models.BooleanField(default=True)),
                ('arrendador', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='inmuebles_publicados', to=settings.AUTH_USER_MODEL)),
                ('comuna', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='inmuebles', to='inmuebles.comuna')),
                ('tipo_inmueble', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='inmuebles', to='inmuebles.tipoinmueble')),
            ],
            options={'ordering': ['nombre']},
        ),
    ]
