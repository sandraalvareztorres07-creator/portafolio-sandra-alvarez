from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import PerfilUsuario, Inmueble

class RegistroUsuarioForm(UserCreationForm):
    email = forms.EmailField(required=True, label='Correo electrónico')
    tipo_usuario = forms.ChoiceField(choices=PerfilUsuario.TIPOS, label='Tipo de usuario')
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username','first_name','last_name','email','tipo_usuario','password1','password2')
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
            PerfilUsuario.objects.update_or_create(usuario=user, defaults={'tipo_usuario':self.cleaned_data['tipo_usuario']})
        return user

class PerfilForm(forms.ModelForm):
    first_name = forms.CharField(max_length=150, required=False, label='Nombre')
    last_name = forms.CharField(max_length=150, required=False, label='Apellido')
    email = forms.EmailField(required=True, label='Correo electrónico')
    class Meta:
        model = PerfilUsuario
        fields = ('rut','direccion','telefono','tipo_usuario')
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.instance and self.instance.pk:
            u=self.instance.usuario
            self.fields['first_name'].initial=u.first_name
            self.fields['last_name'].initial=u.last_name
            self.fields['email'].initial=u.email
    def save(self,commit=True):
        perfil=super().save(commit=False)
        u=perfil.usuario
        u.first_name=self.cleaned_data['first_name']; u.last_name=self.cleaned_data['last_name']; u.email=self.cleaned_data['email']
        if commit:
            u.save(); perfil.save()
        return perfil


class InmuebleForm(forms.ModelForm):
    class Meta:
        model = Inmueble
        fields = ('nombre','descripcion','m2_construidos','m2_totales','cantidad_estacionamientos','cantidad_habitaciones','cantidad_banos','direccion','precio_mensual','comuna','tipo_inmueble','disponible')
        widgets={'descripcion':forms.Textarea(attrs={'rows':4})}
