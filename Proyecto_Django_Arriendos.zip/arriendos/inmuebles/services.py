"""Operaciones CRUD del Hito 1 usando el ORM de Django."""
from .models import Inmueble


def crear_inmueble(**datos):
    """Crea y retorna un inmueble."""
    return Inmueble.objects.create(**datos)


def listar_inmuebles():
    """Enlista los inmuebles con sus relaciones principales."""
    return Inmueble.objects.select_related(
        'comuna__region', 'tipo_inmueble', 'arrendador'
    ).all()


def actualizar_inmueble(inmueble_id, **cambios):
    """Actualiza un inmueble existente y retorna el registro actualizado."""
    inmueble = Inmueble.objects.get(pk=inmueble_id)
    for campo, valor in cambios.items():
        if not hasattr(inmueble, campo):
            raise AttributeError(f'El campo {campo!r} no existe en Inmueble')
        setattr(inmueble, campo, valor)
    inmueble.save()
    return inmueble


def eliminar_inmueble(inmueble_id):
    """Elimina un inmueble por su llave primaria."""
    inmueble = Inmueble.objects.get(pk=inmueble_id)
    inmueble.delete()
    return True
