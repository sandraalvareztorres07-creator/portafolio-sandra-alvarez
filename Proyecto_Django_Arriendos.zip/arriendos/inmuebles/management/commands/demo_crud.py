from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from inmuebles.models import Region, Comuna, TipoInmueble
from inmuebles.services import crear_inmueble, listar_inmuebles, actualizar_inmueble, eliminar_inmueble


class Command(BaseCommand):
    help = 'Demuestra las operaciones CRUD solicitadas en el Hito 1.'

    def handle(self, *args, **options):
        region, _ = Region.objects.get_or_create(nombre='Biobío')
        comuna, _ = Comuna.objects.get_or_create(nombre='Concepción', region=region)
        tipo, _ = TipoInmueble.objects.get_or_create(nombre='Departamento')
        usuario, _ = User.objects.get_or_create(username='arrendador_demo')

        inmueble = crear_inmueble(
            nombre='Departamento Demo',
            descripcion='Inmueble creado para demostrar CRUD.',
            m2_construidos=60,
            m2_totales=65,
            cantidad_estacionamientos=1,
            cantidad_habitaciones=2,
            cantidad_banos=1,
            direccion='Av. Demo 123',
            precio_mensual=450000,
            comuna=comuna,
            tipo_inmueble=tipo,
            arrendador=usuario,
        )
        self.stdout.write(self.style.SUCCESS(f'CREAR: {inmueble} (id={inmueble.id})'))

        self.stdout.write('ENLISTAR:')
        for item in listar_inmuebles():
            self.stdout.write(f' - {item.id}: {item.nombre} / {item.comuna.nombre}')

        inmueble = actualizar_inmueble(inmueble.id, precio_mensual=475000)
        self.stdout.write(self.style.SUCCESS(f'ACTUALIZAR: precio={inmueble.precio_mensual}'))

        eliminar_inmueble(inmueble.id)
        self.stdout.write(self.style.SUCCESS('BORRAR: registro demo eliminado correctamente'))
