from django.conf import settings
from django.db import models


class Region(models.Model):
    nombre = models.CharField(max_length=100, unique=True)

    class Meta:
        ordering = ['nombre']

    def __str__(self):
        return self.nombre


class Comuna(models.Model):
    nombre = models.CharField(max_length=100)
    region = models.ForeignKey(Region, on_delete=models.CASCADE, related_name='comunas')

    class Meta:
        ordering = ['nombre']
        constraints = [
            models.UniqueConstraint(fields=['nombre', 'region'], name='comuna_region_unica')
        ]

    def __str__(self):
        return f'{self.nombre} - {self.region.nombre}'


class TipoInmueble(models.Model):
    nombre = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.nombre


class PerfilUsuario(models.Model):
    ARRENDATARIO = 'arrendatario'
    ARRENDADOR = 'arrendador'
    TIPOS = [
        (ARRENDATARIO, 'Arrendatario'),
        (ARRENDADOR, 'Arrendador'),
    ]

    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='perfil',
    )
    rut = models.CharField(max_length=12, blank=True)
    direccion = models.CharField(max_length=200, blank=True)
    telefono = models.CharField(max_length=20, blank=True)
    tipo_usuario = models.CharField(max_length=20, choices=TIPOS, default=ARRENDATARIO)

    def __str__(self):
        return f'{self.usuario.username} - {self.get_tipo_usuario_display()}'


class Inmueble(models.Model):
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField()
    m2_construidos = models.PositiveIntegerField(default=0)
    m2_totales = models.PositiveIntegerField(default=0)
    cantidad_estacionamientos = models.PositiveIntegerField(default=0)
    cantidad_habitaciones = models.PositiveIntegerField(default=0)
    cantidad_banos = models.PositiveIntegerField(default=0)
    direccion = models.CharField(max_length=200)
    precio_mensual = models.DecimalField(max_digits=12, decimal_places=2)
    comuna = models.ForeignKey(Comuna, on_delete=models.PROTECT, related_name='inmuebles')
    tipo_inmueble = models.ForeignKey(
        TipoInmueble,
        on_delete=models.PROTECT,
        related_name='inmuebles',
    )
    arrendador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='inmuebles_publicados',
    )
    disponible = models.BooleanField(default=True)

    class Meta:
        ordering = ['nombre']

    def __str__(self):
        return self.nombre
