from django.contrib import admin
from .models import Region, Comuna, TipoInmueble, PerfilUsuario, Inmueble


class RegionAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre')
    search_fields = ('nombre',)
    list_filter = ('nombre',)


class ComunaAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'region')
    search_fields = ('nombre', 'region__nombre')
    list_filter = ('region',)


class InmuebleAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'nombre', 'comuna', 'tipo_inmueble',
        'precio_mensual', 'arrendador', 'disponible',
    )
    search_fields = (
        'nombre', 'descripcion', 'direccion',
        'comuna__nombre', 'comuna__region__nombre',
        'arrendador__username',
    )
    list_filter = ('disponible', 'tipo_inmueble', 'comuna__region', 'comuna')


class TipoInmuebleAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre')
    search_fields = ('nombre',)


class PerfilUsuarioAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'tipo_usuario', 'rut', 'telefono')
    search_fields = ('usuario__username', 'rut')
    list_filter = ('tipo_usuario',)


admin.site.register(Region, RegionAdmin)
admin.site.register(Comuna, ComunaAdmin)
admin.site.register(Inmueble, InmuebleAdmin)
admin.site.register(TipoInmueble, TipoInmuebleAdmin)
admin.site.register(PerfilUsuario, PerfilUsuarioAdmin)

admin.site.site_header = 'Administración de Arriendos'
admin.site.site_title = 'Administración de Arriendos'
admin.site.index_title = 'Gestión de inmuebles, regiones y comunas'
