from django.contrib.auth.models import User
from django.test import TestCase
from .models import Region, Comuna, TipoInmueble, Inmueble
from .services import crear_inmueble, listar_inmuebles, actualizar_inmueble, eliminar_inmueble


class CrudInmuebleTest(TestCase):
    def setUp(self):
        self.region = Region.objects.create(nombre='Biobío')
        self.comuna = Comuna.objects.create(nombre='Concepción', region=self.region)
        self.tipo = TipoInmueble.objects.create(nombre='Casa')
        self.user = User.objects.create_user(username='arrendador', password='Prueba123!')

    def test_crud_completo(self):
        inmueble = crear_inmueble(
            nombre='Casa prueba', descripcion='Descripción', direccion='Calle 1',
            precio_mensual=350000, comuna=self.comuna,
            tipo_inmueble=self.tipo, arrendador=self.user,
        )
        self.assertEqual(listar_inmuebles().count(), 1)
        actualizar_inmueble(inmueble.id, nombre='Casa actualizada')
        self.assertEqual(Inmueble.objects.get(pk=inmueble.id).nombre, 'Casa actualizada')
        eliminar_inmueble(inmueble.id)
        self.assertEqual(Inmueble.objects.count(), 0)
