# Hito 2 - Autenticación usando django-auth

## Configuración

`django.contrib.auth` y `django.contrib.contenttypes` están habilitados en `INSTALLED_APPS`.

Rutas:
- `/registro/` → registro mediante `UserCreationForm` personalizado.
- `/accounts/login/` → `LoginView`.
- `/accounts/logout/` → `LogoutView`.
- `/admin/` → panel de administración.

El superusuario de evaluación fue creado en la migración anterior:
- usuario: `admin_inmuebles`
- clave inicial: `AdminInmuebles#2026`

## Registro

`RegistroUsuarioForm` hereda de `UserCreationForm`, incorpora correo y tipo de usuario. Al crear la cuenta se genera/actualiza `PerfilUsuario` y el usuario se agrega al grupo correspondiente.

## Permisos y grupos

La migración `0003_grupos_permisos.py` crea:
- **Arrendatarios**: permiso para visualizar inmuebles.
- **Arrendadores**: permisos para visualizar, crear, modificar y eliminar inmuebles.

## Ejecución

```powershell
python manage.py migrate
python manage.py runserver
```

Pruebas manuales:
1. Registrarse como Arrendatario.
2. Cerrar sesión.
3. Registrarse como Arrendador.
4. Iniciar/cerrar sesión desde el navbar.
5. Revisar Grupos y Permisos en `/admin/`.
