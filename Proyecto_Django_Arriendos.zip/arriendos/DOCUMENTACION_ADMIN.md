# Hito - Configuración del Admin de Django

## 1. Superusuario

El proyecto crea automáticamente un superusuario de demostración al ejecutar las migraciones:

- Usuario: `admin_inmuebles`
- Correo: `admin@inmuebles.cl`
- Contraseña inicial: `AdminInmuebles#2026`

> Credenciales solo para evaluación local. Se recomienda cambiar la contraseña después del primer ingreso.

Comandos:

```powershell
python manage.py migrate
python manage.py runserver
```

Panel: `http://127.0.0.1:8000/admin/`

## 2. Registro de modelos

En `inmuebles/admin.py` se registran explícitamente `Inmueble`, `Region` y `Comuna` utilizando `admin.site.register()`, junto con `TipoInmueble` y `PerfilUsuario`.

## 3. Personalización

- `list_display`: muestra los campos principales en los listados.
- `search_fields`: permite búsqueda por nombre, dirección, región, comuna y usuario.
- `list_filter`: permite filtrar inmuebles por disponibilidad, tipo, región y comuna; comunas por región.
- Se personalizaron los títulos del sitio administrativo.

## 4. Evidencias solicitadas

La pauta exige capturas reales del panel. Al ejecutar el proyecto, guardar en una carpeta `capturas_admin`:

1. `01_login_admin.png`: inicio de sesión del panel.
2. `02_modelos_admin.png`: inicio del admin mostrando Inmuebles, Regiones y Comunas.
3. `03_lista_inmuebles.png`: listado personalizado con columnas y filtros.
4. `04_lista_comunas.png`: comunas con filtro de región.

Las capturas deben realizarse desde el equipo donde corre PostgreSQL/Django; no se incluyen imágenes fabricadas.
