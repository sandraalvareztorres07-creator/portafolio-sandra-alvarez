# Hito 1 - Conectando Django a una base de datos

## 1. Ambiente de desarrollo

1. Instalar PostgreSQL y verificar que el servicio se encuentre iniciado.
2. Crear la base de datos ejecutando `crear_bd.sql` desde pgAdmin o psql.
3. Crear y activar el ambiente virtual:

```powershell
py -3.12 -m venv venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

4. Instalar los paquetes:

```powershell
pip install -r requirements.txt
```

5. Configurar las variables de PostgreSQL si las credenciales son distintas a los valores por defecto usados en `settings.py`:

```powershell
$env:POSTGRES_DB="arriendos_db"
$env:POSTGRES_USER="postgres"
$env:POSTGRES_PASSWORD="TU_CLAVE"
$env:POSTGRES_HOST="localhost"
$env:POSTGRES_PORT="5432"
```

6. Crear/aplicar el esquema:

```powershell
python manage.py migrate
python manage.py check
```

## 2. Modelo de datos

El modelo relacional está documentado en `MODELO_RELACIONAL.md`. Las entidades principales son `Region`, `Comuna`, `TipoInmueble`, `PerfilUsuario` e `Inmueble`. Django crea las llaves primarias automáticamente y las llaves foráneas están implementadas con `ForeignKey` y `OneToOneField`.

La configuración principal de `DATABASES` usa `django.db.backends.postgresql` y obtiene los datos de conexión desde variables de entorno.

## 3. Operaciones CRUD

Las operaciones solicitadas se encuentran en `inmuebles/services.py`:

- `crear_inmueble(**datos)`
- `listar_inmuebles()`
- `actualizar_inmueble(inmueble_id, **cambios)`
- `eliminar_inmueble(inmueble_id)`

Se incluye un comando de demostración:

```powershell
python manage.py demo_crud
```

Este comando crea los registros básicos necesarios, crea un inmueble, lo enlista, lo actualiza y finalmente lo elimina.

También se incluyen pruebas automáticas en `inmuebles/tests.py`. Para ejecutarlas sin depender de PostgreSQL se puede activar temporalmente SQLite solo para pruebas:

```powershell
$env:USE_SQLITE="1"
python manage.py test
Remove-Item Env:USE_SQLITE
```

La configuración normal del proyecto permanece en PostgreSQL.

## 4. Archivos relevantes

- `arriendos/settings.py`: conexión Django/PostgreSQL.
- `inmuebles/models.py`: definición de modelos y relaciones.
- `inmuebles/migrations/0001_initial.py`: esquema inicial.
- `inmuebles/services.py`: CRUD.
- `inmuebles/management/commands/demo_crud.py`: demostración del CRUD.
- `crear_bd.sql`: creación de la base de datos PostgreSQL.
- `MODELO_RELACIONAL.md`: representación del modelo.
