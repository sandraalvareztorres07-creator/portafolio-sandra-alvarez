import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'arriendos.settings')
import django
django.setup()
from django.db import connection

SQL = """
SELECT c.nombre AS comuna, i.nombre, i.descripcion
FROM inmuebles_inmueble i
JOIN inmuebles_comuna c ON i.comuna_id = c.id
WHERE i.disponible = TRUE
ORDER BY c.nombre, i.nombre;
"""
with connection.cursor() as cursor:
    cursor.execute(SQL)
    filas = cursor.fetchall()
with open('reporte_inmuebles_por_comuna.txt','w',encoding='utf-8') as f:
    comuna_actual = None
    for comuna, nombre, descripcion in filas:
        if comuna != comuna_actual:
            comuna_actual = comuna
            f.write(f'\n=== {comuna} ===\n')
        f.write(f'- {nombre}: {descripcion}\n')
print('Reporte generado: reporte_inmuebles_por_comuna.txt')
