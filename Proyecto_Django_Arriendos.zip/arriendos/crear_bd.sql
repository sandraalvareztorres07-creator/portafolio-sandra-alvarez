-- Ejecutar como usuario administrador de PostgreSQL.
CREATE DATABASE arriendos_db;
-- Si utilizas el usuario postgres ya existente, no necesitas crear otro usuario.
-- Recomendación para una cuenta dedicada:
-- CREATE USER arriendos_user WITH PASSWORD 'CambiarEstaClave';
-- GRANT ALL PRIVILEGES ON DATABASE arriendos_db TO arriendos_user;
