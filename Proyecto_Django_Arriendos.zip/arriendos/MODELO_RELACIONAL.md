# Modelo relacional

- **Region** (`id` PK, `nombre`)
- **Comuna** (`id` PK, `nombre`, `region_id` FK → Region)
- **TipoInmueble** (`id` PK, `nombre`)
- **PerfilUsuario** (`id` PK, `usuario_id` FK/1:1 → auth.User, `rut`, `direccion`, `telefono`, `tipo_usuario`)
- **Inmueble** (`id` PK, datos del inmueble, `comuna_id` FK → Comuna, `tipo_inmueble_id` FK → TipoInmueble, `arrendador_id` FK → auth.User)

Relaciones:

```text
Region 1 ───── N Comuna 1 ───── N Inmueble N ───── 1 TipoInmueble
                                      │
                                      N
                                      │
                                      1
                                  auth.User
                                      │
                                      1
                                      │
                                      1
                                PerfilUsuario
```

Las llaves primarias son generadas automáticamente por Django y las relaciones se implementan mediante `ForeignKey`/`OneToOneField`.
