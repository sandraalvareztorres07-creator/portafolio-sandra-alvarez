import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'arriendos.settings')
import django
django.setup()
from django.db import connection

SQL = """
SELECT r.nombre AS region, i.nombre, i.descripcion, c.nombre AS comuna
FROM inmuebles_inmueble i
JOIN inmuebles_comuna c ON i.comuna_id = c.id
JOIN inmuebles_region r ON c.region_id = r.id
WHERE i.disponible = TRUE
ORDER BY r.nombre, c.nombre, i.nombre;
"""
with connection.cursor() as cursor:
    cursor.execute(SQL)
    filas = cursor.fetchall()
with open('reporte_inmuebles_por_region.txt','w',encoding='utf-8') as f:
    region_actual = None
    for region, nombre, descripcion, comuna in filas:
        if region != region_actual:
            region_actual = region
            f.write(f'\n=== {region} ===\n')
        f.write(f'- {nombre} ({comuna}): {descripcion}\n')
print('Reporte generado: reporte_inmuebles_por_region.txt')
